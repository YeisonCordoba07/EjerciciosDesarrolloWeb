package com.example.proyectoestudio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoestudioApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoestudioApplication.class, args);
	}

}
